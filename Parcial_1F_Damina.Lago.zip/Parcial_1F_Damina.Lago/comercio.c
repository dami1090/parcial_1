#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "comercio.h"
#include "proveedor.h"
#include "utn.h"


int inicializar(eProducto lista[],int tam)
{
    int i;
    for(i=0; i<tam; i++)
    {
        lista[i].estado=0;
    }
    return 0;
}

int obtenerEspacioLibre(eProducto lista[],int tam)
{
    int i;
    int indice=-1;

    for(i=0; i<tam; i++)
    {
        if(lista[i].estado == 0)
        {
            indice=i;
            break;
        }
    }

    return indice;
}

void alta(eProducto lista[],int tam,eProveedor prove[],int prov)
{

    int indice,repetido,aux,i,codigo,flag=0;
    char auxCod[21],auxProveedor[51],preguntar='n';
    eProducto auxProducto;



    indice=obtenerEspacioLibre(lista,tam);
    if(indice !=-1)
    {
        do
        {
            do
            {
                aux=getStringNumeros("ingrese codigo para el producto\n",auxCod);
                if(aux!=1)
                {
                    printf("\n codigo incorrecto, recuerde utilizar solo numeros\n\n");
                }
                else
                {
                    codigo=atoi(auxCod);
                }
            }
            while(aux!=1);

            repetido=buscarProducto(lista,tam,codigo);
            if(repetido==-1)
            {
                auxProducto.codigo=codigo;
                do
                {
                    aux=getStringDescripcion("ingrese la descripcion\n",auxProducto.descrip);
                    if(aux!=1 || (strlen(auxProducto.descrip)>50))
                    {
                        printf("\n descripcion incorrecta,recuerde utilizar unicamente numeros o letras,\nNi excederse de 50 caracteres\n\n");
                    }
                }
                while(aux!=1 || (strlen(auxProducto.descrip)>50));

                do
                {
                    aux=getStringFloat("ingrese el importe del producto\n",auxCod);
                    if(aux!=1)
                    {
                        printf("\n importe incorrecto, recuerde utilizar solo numeros y un punto para los decimales,\n ejemplo: 7.60 \n\n");
                    }
                    else
                    {
                        auxProducto.importe=atof(auxCod);
                    }
                }
                while(aux!=1);

                do
                {
                    aux=getStringNumeros("ingrese cantidad de stock\n",auxCod);
                    if(aux!=1)
                    {
                        printf("\n cantidad incorrecta, recuerde utilizar solo numeros\n\n");
                    }
                    else
                    {
                        auxProducto.cantidad=atoi(auxCod);
                    }
                }
                while(aux!=1);
                do
                {
                    do
                    {
                        system("cls");
                        printf("lista de proveedores\n");
                        for(i=0; i<prov; i++)
                        {
                            printf("\tProveedor: %s\n",prove[i].nombreProveedor);
                        }
                        setbuf(stdin,NULL);
                        aux=getStringDescripcion("\ningrese nombre\n",auxProveedor);
                        if(aux!=1 || (strlen(auxProveedor)>50))
                        {
                            printf("\n descripcion incorrecta,recuerde utilizar unicamente numeros o letras,\nNi excederse de 50 caracteres\n\n");
                            system("pause");
                        }
                    }
                    while(aux!=1 || (strlen(auxProveedor)>50));
                    strlwr(auxProveedor);
                    for(i=0; i<prov; i++)
                    {
                        if(strcmp(auxProveedor,prove[i].nombreProveedor)==0)
                        {
                            flag=1;
                            strcpy(auxProducto.nombreProveedor,prove[i].nombreProveedor);
                            auxProducto.estado=1;
                            break;
                        }
                        else
                        {
                            flag=0;

                        }
                    }
                    if(flag==0)
                    {
                        printf("\n proveedor incorrecto\n");
                        system("pause");
                    }
                }

                while(flag!=1);
            }
            else
            {
                printf("el codigo REPETIDO\n");
                system("pause");
            }
        }
        while(repetido!=-1);

    }
    else
    {
        printf("no queda mas espacio en el sistema para seguir cargando productos!\n");
    }


    system("cls");
    printf("Descripcion: %s\nCodigo:%d\nimporte: %.2f\nStock:%d\nProveedor: %s\n\n",auxProducto.descrip,auxProducto.codigo,auxProducto.importe,auxProducto.cantidad,auxProducto.nombreProveedor);
    printf("El producto que desea agregar, tiene los campos correctamente completados? [s|n]");
    setbuf(stdin,NULL);
    scanf("%c",&preguntar);
    preguntar=tolower(preguntar);



    if(preguntar=='s')
    {
        lista[indice]=auxProducto;
        printf("\nproducto cargado correctamente\n");
    }
    else
        printf("\n El producto no se ha guardado\n");
    return;
}

void mostrarTodos(eProducto lista[],int tam)
{
    int i;
    printf("Codigo\tPrecio\tCantidad\tDescripcion\n");
    for(i=0; i<tam; i++)
    {
        if(lista[i].estado ==1)
        {
            mostrarProducto(lista[i]);
        }

    }
    return;
}

int baja(eProducto lista[],int tam)
{
    int aux,auxIndice,codigo;
    char numeros[15];
    char seguir='n';
    do
    {
        aux=getStringNumeros("escriba el codigo del producto que desea dar de baja\n",numeros);
        if(aux!=1)
        {
            printf("\n Codigo incorrecto, recuerde utilizar solo numeros \n\n");
        }
        else
        {
            codigo=atoi(numeros);
        }
    }
    while(aux!=1);

    auxIndice=buscarProducto(lista,tam,codigo);
    if(auxIndice == -1  || lista[auxIndice].estado==0)
    {
        printf("el codigo: %d ,no se ha encontrado o ya ha sido dado de baja\n",codigo);
    }
    else
    {
        mostrarProducto(lista[auxIndice]);

        printf("�es el producto q desea borrar? [s|n]\n");
        setbuf(stdin,NULL);
        scanf("%c",&seguir);
        seguir=tolower(seguir);
        if(seguir=='s')
        {
            lista[auxIndice].estado=0;
            printf("el producto ha sido dado de baja correctamente\n");
        }
        else
        {
            printf("el producto NO se borrara\n");
        }
    }
    return 0;
}


int modificar(eProducto lista[],int tam)
{
    eProducto auxProducto;
    int aux,auxIndice,codigo;
    char numeros[15];
    char seguir='s';
    int opcion=0;
    do
    {
        aux=getStringNumeros("escriba el codigo del producto que desea modificar\n",numeros);
        if(aux!=1)
        {
            printf("\n Codigo incorrecto, recuerde utilizar solo numeros \n\n");
        }
        else
        {
            codigo=atoi(numeros);
        }
    }
    while(aux!=1);

    auxIndice=buscarProducto(lista,tam,codigo);
    if(auxIndice == -1  || lista[auxIndice].estado==0)
    {
        printf("el codigo: %d ,no se ha encontrado o ya ha sido dado de baja\n",codigo);
    }
    else
    {

        auxProducto=lista[auxIndice];
        mostrarProducto(auxProducto);
        printf("�es el producto q desea modificar? [s|n]");
        setbuf(stdin,NULL);
        scanf("%c",&seguir);
        seguir=tolower(seguir);
        while(seguir=='s')
        {
            printf("1- modificar descripcion\n");
            printf("2- Modificar importe\n");
            printf("3- modificar stock\n\n");
            printf("4- Salir\n");
            setbuf(stdin,NULL);
            scanf("%d",&opcion);


            switch(opcion)
            {
            case 1:
                do
                {
                    aux=getStringDescripcion("ingrese la descripcion\n",auxProducto.descrip);
                    if(aux!=1 || (strlen(auxProducto.descrip)>50))
                    {
                        printf("\n descripcion incorrecta,recuerde utilizar unicamente numeros o letras,\nNi excederse de 50 caracteres\n\n");
                    }
                }
                while(aux!=1 || (strlen(auxProducto.descrip)>50));

                break;
            case 2:
                do
                {
                    aux=getStringFloat("ingrese el importe del producto\n",numeros);
                    if(aux!=1)
                    {
                        printf("\n importe incorrecto, recuerde utilizar solo numeros y un punto para los decimales,\n ejemplo: 7.60 \n\n");
                    }
                    else
                    {
                        auxProducto.importe=atof(numeros);
                    }
                }
                while(aux!=1);
                break;
            case 3:
                do
                {
                    aux=getStringNumeros("ingrese el nuevo stock: \n",numeros);
                    if(aux!=1)
                    {
                        printf("\n cantidad incorrecta, recuerde utilizar solo numeros\n\n");
                    }
                    else
                    {
                        auxProducto.cantidad=atoi(numeros);
                    }
                }
                while(aux!=1);

                break;
            case 4:
                seguir = 'n';
                break;

            default:
                system("cls");
                printf("\n\tOpcion invalida\n\n");
                break;
            }
            system("pause");
            system("cls");
        }
        printf("\n\n\t\tModificaciones\n\n");
        mostrarProducto(auxProducto);
        printf("�Desea guardar los cambios? [s|n]\n");
        setbuf(stdin,NULL);
        scanf("%c",&seguir);
        seguir=tolower(seguir);
        if(seguir=='s')
        {
            lista[auxIndice]=auxProducto;
            printf("\nSe realizaron los cambioscon exito\n");
        }
        else
        {
            printf("No se ha modificado el producto en cuestion\n");
        }
    }



    return 0;
}

void mostrarProducto(eProducto producto)
{
    printf("%d\t%.2f\t%d\t\t%s\n",producto.codigo,producto.importe,producto.cantidad,producto.descrip);
    return;
}

int buscarProducto(eProducto lista[],int tam,int codigo)
{
    int i;
    int indice= -1;
    for(i=0; i<tam; i++)
    {
        if(lista[i].estado==1 && lista[i].codigo==codigo)
        {
            indice=i;
            break;
        }
    }
    return indice;
}


void orden(eProducto lista[],int tam)
{
    eProducto aux;
    int i,j;
    for(i=0; i<tam-1; i++)
    {
        for(j=i+1; j<tam; j++)
        {
            if(lista[i].importe<lista[j].importe)
            {
                aux=lista[i];
                lista[i]=lista[j];
                lista[j]=aux;
            }
            else if(lista[i].importe==lista[j].importe)
            {

                if(strcmp(lista[i].descrip,lista[j].descrip)<0)
                {
                    aux=lista[i];
                    lista[i]=lista[j];
                    lista[j]=aux;
                }
            }
        }
    }

    mostrarTodos(lista,tam);
    return;
}

void informar(eProducto lista[],int tam,eProveedor prov[],int cant)
{
    int i;
    float promedio=0;
    float total=0;
    int acumulador=0;
    int acumuladorMayor=0;
    int acumuladorMenor=0;
    int acuMenos10=0;
    int acuMas10=0;

    for(i=0; i<tam; i++)
    {
        if(lista[i].estado ==1)
        {
            total=total+lista[i].importe;
            acumulador++;
        }

    }
    promedio=total/acumulador;
    for(i=0; i<tam; i++)
    {
        if(lista[i].estado==1)
        {
            if(lista[i].importe>=promedio)
            {
                acumuladorMayor++;

            }
            else
            {
                acumuladorMenor++;
            }
        }
    }

    for(i=0; i<tam; i++)
    {
        if(lista[i].estado==1)
        {
            if(lista[i].cantidad<=10)
            {
                acuMenos10++;

            }
            else
            {
                acuMas10++;
            }
        }
    }

    for(i=0; i<tam; i++)
    {
        if(lista[i].estado==1)
        {
            if(lista[i].importe>=promedio)
            {
                printf("\n\tproducto q supera el promedio(%.2f)de precio: %s--%.2f\n",promedio,lista[i].descrip,lista[i].importe);

            }
        }
    }
    system("pause");
    for(i=0; i<tam; i++)
    {
        if(lista[i].estado==1)
        {
            if(lista[i].importe<promedio)
            {
                printf("\n\tproducto q no supera el promedio(%.2f) de precio: %s--%.2f\n",promedio,lista[i].descrip,lista[i].importe);

            }
        }
    }
    system("pause");

    for(i=0; i<tam; i++)
    {
        if(lista[i].estado==1)
        {
            if(lista[i].cantidad<=10)
            {
                printf("\n\tproducto con stock menor o igual a 10: %s---cantidad:%d\n",lista[i].descrip,lista[i].cantidad);

            }
        }
    }
    system("pause");

    for(i=0; i<tam; i++)
    {
        if(lista[i].estado==1)
        {
            if(lista[i].cantidad>10)
            {
                printf("\n\tproducto con stock mayor a 10: %s---cantidad:%d\n",lista[i].descrip,lista[i].cantidad);

            }
        }
    }
    system("pause");
    system("cls");
    printf("\n\t\ttotal: %.2f\tpromedio: %.2f\tcantidad de productos: %d\n\n",total,promedio,acumulador);
    printf("\tproductos q superan el promedio: %d\tProductos q no superan el promedio: %d\n\n",acumuladorMayor,acumuladorMenor);
    printf("\tproductos con mas de 10: %d\n\n",acuMas10);
    printf("\tproductos con stock menor a 10: %d\n",acuMenos10);

}

void informarMuchos(eProducto lista[],int tam,eProveedor prov[],int cant)
{
    int i,j,acumas=0,acumenos=0;
    float max=0,min=0;

    printf("\nproveedor \t---\tproductos\n");
    for(i=0; i<cant; i++)
    {
        for(j=0; j<tam; j++)
        {
            if(strcmp(prov[i].nombreProveedor,lista[j].nombreProveedor) == 0 && lista[j].estado==1)
            {
                printf("\n%s\t---\t%-15s\n",prov[i].nombreProveedor,lista[j].descrip);
            }
        }
    }
    system("pause");
    max=lista[0].importe;
    min=lista[0].importe;
    for(i=0; i<cant; i++)
    {
        for(j=0; j<tam; j++)
        {
            if(strcmp(prov[i].nombreProveedor,lista[j].nombreProveedor) == 0 && lista[j].estado==1)
            {

                if(max<lista[j].importe)
                {
                    max=lista[j].importe;

                }
                if(min>lista[j].importe)
                {
                    min=lista[j].importe;

                }
            }
        }
    }
    printf("\n\nProducto mas caro\tprecio\tProveedor\n");
    for(i=0; i<cant; i++)
    {
        for(j=0; j<tam; j++)
        {
            if(strcmp(prov[i].nombreProveedor,lista[j].nombreProveedor) == 0 && lista[j].estado==1)
            {
                if(max==lista[j].importe)
                {
                    printf("\n%s\t\t%.2f\t%s\n",lista[j].descrip,lista[j].importe,lista[j].nombreProveedor);
                }

            }
        }
    }
    system("pause");
    printf("\n\nProducto mas barato\tprecio\tProveedor\n");
    for(i=0; i<cant; i++)
    {
        for(j=0; j<tam; j++)
        {
            if(strcmp(prov[i].nombreProveedor,lista[j].nombreProveedor) == 0 && lista[j].estado==1)
            {
                if(min==lista[j].importe)
                {
                    printf("\n%s\t\t%-15.2f\t%-15s\n",lista[j].descrip,lista[j].importe,lista[j].nombreProveedor);
                }

            }
        }
    }

    system("pause");
    system("cls");
    acumenos=lista[0].cantidad;
    acumas=lista[0].cantidad;
    for(i=0; i<cant; i++)
    {
        for(j=0; j<tam; j++)
        {
            if(strcmp(prov[i].nombreProveedor,lista[j].nombreProveedor) == 0 && lista[j].estado==1)
            {
                if(acumas<lista[j].cantidad)
                {
                    acumas=lista[j].cantidad;

                }
                if(acumenos>lista[j].cantidad)
                {
                    acumenos=lista[j].cantidad;
                }
            }
        }
    }
    printf("\n\nProveedor con mas productos:\n");
    printf("*********************************\n");
    printf("Proveedor\tProducto\tCantidad\n");
    for(i=0; i<cant; i++)
    {
        for(j=0; j<tam; j++)
        {
            if(strcmp(prov[i].nombreProveedor,lista[j].nombreProveedor) == 0 && lista[j].estado==1)
            {
                if(acumas==lista[j].cantidad)
                {
                    printf("\n%s\t%-15s\t\t%d\n",lista[j].nombreProveedor,lista[j].descrip,lista[j].cantidad);
                }

            }
        }
    }
    system("pause");
    printf("\n\nProveedor con menos productos:\n");

    printf("Proveedor\tProducto\tCantidad\n");
    printf("*********************************\n");
    for(i=0; i<cant; i++)
    {
        for(j=0; j<tam; j++)
        {
            if(strcmp(prov[i].nombreProveedor,lista[j].nombreProveedor) == 0 && lista[j].estado==1)
            {
                if(acumenos==lista[j].cantidad)
                {
                    printf("\n%s\t%-15s\t\t%d\n",lista[j].nombreProveedor,lista[j].descrip,lista[j].cantidad);
                }

            }
        }
    }
    return;
}

void informarCantidad(eProducto lista[],int tam,eProveedor prov[],int cant)
{
    int i,j,max,min,acu[cant];
    for(i=0; i<cant; i++)
    {
        acu[i]=0;
    }

    for(i=0; i<cant; i++)
    {
        for(j=0; j<tam; j++)
        {
            if(strcmp(prov[i].nombreProveedor,lista[j].nombreProveedor) == 0 && lista[j].estado==1)
            {
                acu[i]++;
            }
        }
    }
    /* for(i=0; i<cant; i++)
    {
        printf("acu[i]:%d\ti:%d\n",acu[i],i);
    }*/
    max=acu[0];
    min=acu[0];

    for(i=0; i<cant; i++)
    {
        if(max<acu[i])
        {
            max=acu[i];
            //indiceMax=i;
        }
        if(min>acu[i])
        {
            min=acu[i];
            //indiceMin=i;
        }
    }
    system("pause");
    printf("proveedor con mas producto\n");
    printf("****************************\n");
    for(i=0; i<cant; i++)
    {
        for(j=0; j<tam; j++)
        {
            if(max==acu[i])
            {
                if(strcmp(prov[i].nombreProveedor,lista[j].nombreProveedor) == 0 && lista[j].estado==1)
                {
                    printf("%s\t%-20s\n",prov[i].nombreProveedor,lista[j].descrip);
                }
            }
        }
    }
    system("pause");
    printf("proveedor con menos producto\n");
    printf("****************************\n");
    for(i=0; i<cant; i++)
    {
        for(j=0; j<tam; j++)
        {
            if(min==acu[i])
            {
                if(strcmp(prov[i].nombreProveedor,lista[j].nombreProveedor) == 0 && lista[j].estado==1)
                {
                    printf("%s\t%-20s\n",prov[i].nombreProveedor,lista[j].descrip);
                }
            }
        }
    }


}

void mostrarProveedor(eProducto lista[],int tam,eProveedor prov[],int cant)
{
    int i,j,aux;
    char auxProveedor[51];
    do
    {
        printf("lista de proveedores\n");
        for(i=0; i<cant; i++)
        {
            printf("\tProveedor: %s\n",prov[i].nombreProveedor);
        }
        setbuf(stdin,NULL);
        aux=getStringDescripcion("\ningrese nombre\n",auxProveedor);
        if(aux!=1 || (strlen(auxProveedor)>50))
        {
            printf("\n descripcion incorrecta,recuerde utilizar unicamente numeros o letras,\nNi excederse de 50 caracteres\n\n");
            system("pause");
            system("cls");
        }
    }
    while(aux!=1 || (strlen(auxProveedor)>50));
    strlwr(auxProveedor);
    for(i=0; i<cant; i++)
    {
        if(strcmp(auxProveedor,prov[i].nombreProveedor)==0)
        {
            break;
        }
    }
    printf("\n\tProveedor: %s\n",prov[i].nombreProveedor);
    printf("Codigo\tPrecio\tCantidad\tDescripcion\n");
    for(j=0; j<tam; j++)
    {
        if(strcmp(prov[i].nombreProveedor,lista[j].nombreProveedor)==0 && lista[j].estado==1)
        mostrarProducto(lista[j]);
    }
}

int cantidadCargada(eProducto lista[],int tam)
{
    int i,acu=0;
    for(i=0; i<tam; i++)
    {
        if(lista[i].estado==1)
        {
            acu++;
        }


    }
    return acu;
}
