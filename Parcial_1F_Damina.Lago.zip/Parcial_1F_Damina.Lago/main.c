#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "comercio.h"
#include "proveedor.h"
#define TAM 20
#define PROVE 5

int main()
{


    char seguir='s';
    int opcion=0;
    int cant=0;
    eProducto producto[TAM];
    eProveedor prove[]= {{1,1,"milka"},{1,2,"kraftfood"},{1,3,"p&g"},{1,4,"hp"},{1,5,"unilever"}};
    inicializar(producto,TAM);


    while(seguir=='s')
    {

        cant=cantidadCargada(producto,TAM);
        printf("1- Agregar producto---cantidad de productos cargados:%d\n",cant);
        printf("2- Modificar producto\n");
        printf("3- Borrar producto\n");
        printf("4- Imprimir lista\n");
        printf("5- Ordenar y mostrar\n");
        printf("6- Imprimir lista por provedores\n");
        printf("7- Imprimir lista por provedore especifico\n");
        printf("8- Salir\n");

        setbuf(stdin,NULL);
        scanf("%d",&opcion);

        switch(opcion)
        {
        case 1:

            alta(producto,TAM,prove,PROVE);
            break;

        case 2:
            if(cant!=0)
            {
                modificar(producto,TAM);
            }
            else
            {
                printf("primero debera cargar al menos un producto\n");
            }
            break;
        case 3:
            if(cant!=0)
            {
                baja(producto,TAM);
            }
            else
            {
                printf("primero debera cargar al menos un producto\n");
            }
            break;
        case 4:
            if(cant!=0)
            {
                mostrarTodos(producto,TAM);
                system("\n\npause\n");
                system("cls");
                informar(producto,TAM,prove,PROVE);
            }
            else
            {
                printf("primero debera cargar al menos un producto\n");
            }
            break;
        case 5:
            if(cant!=0)
            {
                mostrarTodos(producto,TAM);
                system("\n\npause\n");
                orden(producto,TAM);
            }
            else
            {
                printf("primero debera cargar al menos un producto\n");
            }
            break;
        case 6:
            if(cant!=0)
            {
                informarMuchos(producto,TAM,prove,PROVE);
                informarCantidad(producto,TAM,prove,PROVE);
            }
            else
            {
                printf("primero debera cargar al menos un producto\n");
            }
            break;

        case 7:
            if(cant!=0)
            {
                mostrarProveedor(producto,TAM,prove,PROVE);
            }
            else
            {
                printf("primero debera cargar al menos un producto\n");
            }

            break;
        case 8:
             seguir = 'n';
            break;

        default:
            system("cls");
            printf("\n\tOpcion invalida\n\n");
            break;
        }
        system("pause");
        system("cls");
    }

    return 0;
}
