#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED
#include "comercio.h"


typedef struct
{
    int estado;
    int idProveedor;
    char nombreEmpresa[51];

}eProveedor;

#endif // FUNCIONES_H_INCLUDED
