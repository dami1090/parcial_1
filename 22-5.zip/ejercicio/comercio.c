#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "comercio.h"


int inicializar(eProducto lista[],int tam)
{
    int i;
    for(i=0; i<tam; i++)
    {
        lista[i].estado=0;
    }
    return 0;
}

int obtenerEspacioLibre(eProducto lista[],int tam)
{
    int i;
    int indice=-1;

    for(i=0; i<tam; i++)
    {
        if(lista[i].estado == 0)
        {
            indice=i;
            break;
        }
    }

    return indice;
}

void alta(eProducto lista[],int tam,eProveedor prove[],int prov)
{

    int indice,repetido,aux,i,flag=0;
    char auxCod[20],resp[5];
    indice=obtenerEspacioLibre(lista,tam);

    if(indice !=-1)
    {
        do
        {
            printf("ingrese codigo: \n");
            setbuf(stdin,NULL);
            scanf("%[^\n]",auxCod);
        }
        while(!esNumerico(auxCod));
        aux=atoi(auxCod);


        repetido=buscarProducto(lista,tam,aux);
        if(repetido==-1)
        {


            lista[indice].codigo=aux;
            printf("ingrese la descripcion: \n");
            setbuf(stdin,NULL);
            scanf("%[^\n]",lista[indice].descrip);
            printf("ingrese el importe: \n");
            setbuf(stdin,NULL);
            scanf("%f",&lista[indice].importe);
            printf("ingrese el stock: \n");
            setbuf(stdin,NULL);
            scanf("%d",&lista[indice].cantidad);
            while(flag == 0)
            {
                printf("Escriba el proveedor del producto\n");
                for(i=0; i<prov; i++)
                {
                    printf("Proveedor: %s\n",prove[i].nombreEmpresa);
                }


                setbuf(stdin,NULL);
                scanf("%[^\n]",resp);
                strlwr(resp);
                for(i=0; i<prov; i++)
                {
                    if(strcmp(resp,prove[i].nombreEmpresa)==0)
                    {
                        flag=1;
                        lista[indice].idProveedor =prove[i].idProveedor;
                        lista[indice].estado=1;
                        printf("\nproducto cargado correctamente\n");
                    }
                }
            }


        }
        else
        {
            printf("el codigo REPETIDO\n");
        }
    }
    else
    {
        printf("no queda mas espacio en el sistema para seguir cargando productos!\n");
    }

    return;
}

void mostrar(eProducto lista[],int tam)
{
    int i;

    for(i=0; i<tam; i++)
    {
        if(lista[i].estado ==1)
        {
            mostrarProducto(lista[i]);
        }

    }
    return;
}

int baja(eProducto lista[],int tam)
{
    eProducto auxProducto;
    int aux,auxIndice;

    char seguir;
    printf("escriba el codigo del producto que desea dar de baja\n");
    scanf("%d",&aux);
    auxIndice=buscarProducto(lista,tam,aux);
    if(auxIndice == -1  || lista[auxIndice].estado==0)
    {
        printf("el codigo: %d ,no se ha encontrado o ya ha sido dado de baja\n",aux);
    }
    else
    {

        auxProducto=lista[auxIndice];
        mostrarProducto(auxProducto);

        printf("�es el producto q desea borrar? [s|n]");
        setbuf(stdin,NULL);
        scanf("%c",&seguir);
        seguir=tolower(seguir);
        if(seguir=='s')
        {
            lista[auxIndice].estado=0;
            printf("el producto ha sido dado de baja correctamente\n");
        }
        else
        {
            printf("el producto NO se borrara\n");
        }
    }
    return 0;
}


int modificar(eProducto lista[],int tam)
{
    eProducto auxProducto;
    int aux,auxIndice;
    int flag=0;
    char seguir='s';
    int opcion=0;

    printf("escriba el codigo del producto que desea modificar\n");
    scanf("%d",&aux);
    auxIndice=buscarProducto(lista,tam,aux);
    if(auxIndice == -1  || lista[auxIndice].estado==0)
    {
        printf("el codigo: %d ,no se ha encontrado o ya ha sido dado de baja\n",aux);
    }
    else
    {
        flag=1;
        auxProducto=lista[auxIndice];
        mostrarProducto(auxProducto);
        printf("�es el producto q desea modificar? [s|n]");
        setbuf(stdin,NULL);
        scanf("%c",&seguir);
        seguir=tolower(seguir);
        while(seguir=='s')
        {
            printf("1- modificar descripcion\n");
            printf("2- Modificar importe\n");
            printf("3- modificar stock\n\n");
            printf("4- Salir\n");
            setbuf(stdin,NULL);
            scanf("%d",&opcion);


            switch(opcion)
            {
            case 1:
                printf("ingrese la descripcion: \n");
                setbuf(stdin,NULL);
                scanf("%[^\n]",lista[auxIndice].descrip);
                break;
            case 2:
                printf("ingrese el importe: \n");
                setbuf(stdin,NULL);
                scanf("%f",&lista[auxIndice].importe);
                break;
            case 3:
                printf("ingrese el stock: \n");
                setbuf(stdin,NULL);
                scanf("%d",&lista[auxIndice].cantidad);
                break;
            case 4:
                seguir = 'n';
                break;

            default:
                system("cls");
                printf("\n\tOpcion invalida\n\n");
                break;
            }
            system("pause");
            system("cls");
        }
    }

    if(flag!=0)
    {
        printf("el producto ha sido modificado correctamente\n");
    }

    return 0;
}

void mostrarProducto(eProducto producto)
{
    printf("codigo: %d\tprecio: %.2f\tstock: %d\ndescripcion: %s\n\n",producto.codigo,producto.importe,producto.cantidad,producto.descrip);
    return;
}

int buscarProducto(eProducto lista[],int tam,int codigo)
{
    int i;
    int indice= -1;
    for(i=0; i<tam; i++)
    {
        if(lista[i].estado==1 && lista[i].codigo==codigo)
        {
            indice=i;
            break;
        }
    }
    return indice;
}


void orden(eProducto lista[],int tam)
{
    eProducto aux;
    int i,j;
    for(i=0; i<tam-1; i++)
    {
        for(j=i+1; j<tam; j++)
        {
            if(lista[i].importe<lista[j].importe)
            {
                aux=lista[i];
                lista[i]=lista[j];
                lista[j]=aux;
            }
            else if(lista[i].importe==lista[j].importe)
            {

                if(strcmp(lista[i].descrip,lista[j].descrip)<0)
                {
                    aux=lista[i];
                    lista[i]=lista[j];
                    lista[j]=aux;
                }
            }
        }
    }

    mostrar(lista,tam);
    return;
}

void informar(eProducto lista[],int tam,eProveedor prov[],int cant)
{
    int i;
    float promedio=0;
    float total=0;
    int acumulador=0;
    int acumuladorMayor=0;
    int acumuladorMenor=0;
    int acuMenos10=0;
    int acuMas10=0;

    for(i=0; i<tam; i++)
    {
        if(lista[i].estado ==1)
        {
            total=total+lista[i].importe;
            acumulador++;
        }

    }
    promedio=total/acumulador;
    for(i=0; i<tam; i++)
    {
        if(lista[i].estado==1)
        {
            if(lista[i].importe>=promedio)
            {
                acumuladorMayor++;

            }
            else
            {
                acumuladorMenor++;
            }
        }
    }

    for(i=0; i<tam; i++)
    {
        if(lista[i].estado==1)
        {
            if(lista[i].cantidad<=10)
            {
                acuMenos10++;

            }
            else
            {
                acuMas10++;
            }
        }
    }

    for(i=0; i<tam; i++)
    {
        if(lista[i].estado==1)
        {
            if(lista[i].importe>=promedio)
            {
                printf("\n\n\tproducto q supera el promedio(%.2f)de precio: %s--%.2f\n",promedio,lista[i].descrip,lista[i].importe);

            }
        }
    }
    system("pause");
    for(i=0; i<tam; i++)
    {
        if(lista[i].estado==1)
        {
            if(lista[i].importe<promedio)
            {
                printf("\n\n\tproducto q no supera el promedio(%.2f) de precio: %s--%.2f\n",promedio,lista[i].descrip,lista[i].importe);

            }
        }
    }
    system("pause");

    for(i=0; i<tam; i++)
    {
        if(lista[i].estado==1)
        {
            if(lista[i].cantidad<=10)
            {
                printf("\n\n\tproducto con stock menor o igual a 10: %s---cantidad:%d\n",lista[i].descrip,lista[i].cantidad);

            }
        }
    }
    system("pause");

    for(i=0; i<tam; i++)
    {
        if(lista[i].estado==1)
        {
            if(lista[i].cantidad>10)
            {
                printf("\n\n\tproducto con stock mayor a 10: %s---cantidad:%d\n",lista[i].descrip,lista[i].cantidad);

            }
        }
    }
    system("pause");

    printf("\n\t\ttotal: %.2f\tpromedio: %.2f\tcantidad de productos: %d\n\n",total,promedio,acumulador);
    printf("\tproductos q superan el promedio: %d\tProductos q no superan el promedio: %d\n\n",acumuladorMayor,acumuladorMenor);
    printf("\tproductos con mas de 10: %d\n\n",acuMas10);
    printf("\tproductos con stock menor a 10: %d\n",acuMenos10);

}

void informarMuchos(eProducto lista[],int tam,eProveedor prov[],int cant)
{
    int i,j;
    printf("\nprovedor \t---\tproductos\n");
    for(i=0; i<cant; i++)
    {
        for(j=0; j<tam; j++)
        {
            if(prov[i].idProveedor == lista[j].idProveedor)
            {
                printf("\n%s\t---\t%s\n",prov[i].nombreEmpresa,lista[j].descrip);
            }
        }
    }

    return;
}


int esNumerico(char str[])
{
    int i=0;
    while(str[i] != '\0')
    {
        if((str[i] < '0' || str[i] > '9') && (str[i]!= '.') && (str[i]!= '-'))
            return 0;
        i++;
    }
    return 1;
}

int cantidadCargada(eProducto lista[],int tam)
{
    int i,acu;
    for(i=0;i<tam;i++)
    {
        if(lista[i].estado==1)
        {
            acu++;
        }

    }
    return acu;
}
