#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "comercio.h"


int inicializar(eProducto lista[],int tam)
{
    int i;
    for(i=0; i<tam; i++)
    {
        lista[i].estado=0;
    }
    return 0;
}

int obtenerEspacioLibre(eProducto lista[],int tam)
{
    int i;
    int indice=-1;

    for(i=0; i<tam; i++)
    {
        if(lista[i].estado == 0)
        {
            indice=i;
            break;
        }
    }

    return indice;
}

void alta(eProducto lista[],int tam)
{

    int indice,repetido,aux,auxProve;
    indice=obtenerEspacioLibre(lista,tam);

    if(indice !=-1)
    {

            printf("ingrese codigo: \n");
            setbuf(stdin,NULL);
            scanf("%d",&aux);
            repetido=buscarProducto(lista,tam,aux);
        if(repetido==-1)
        {


            lista[indice].codigo=aux;
            printf("ingrese la descripcion: \n");
            setbuf(stdin,NULL);
            scanf("%[^\n]",lista[indice].descrip);
            printf("ingrese el importe: \n");
            setbuf(stdin,NULL);
            scanf("%f",&lista[indice].importe);
            printf("ingrese el stock: \n");
            setbuf(stdin,NULL);
            scanf("%d",&lista[indice].cantidad);
            lista[indice].estado=1;

             printf("seleccione al proveedor del producto\n");
            printf("1- milka\n");
            printf("2- kraftfood\n");
            printf("3- p&g\n");
            printf("4- unilever\n");
            printf("5- hp\n");
            scanf("%d",&lista[indice].idProveedor);

        }
        else
        {
            printf("el codigo REPETIDO\n");
        }
    }
    else
    {
        printf("no queda mas espacio en el sistema para seguir cargando productos!\n");
    }
    return;
}

void mostrar(eProducto lista[],int tam)
{
    int i;

    for(i=0; i<tam; i++)
    {
        if(lista[i].estado ==1)
        {
            mostrarProducto(lista[i]);
        }

    }
    return;
}

int baja(eProducto lista[],int tam)
{
    eProducto auxProducto;
    int aux,auxIndice;

    char seguir;
    printf("escriba el codigo del producto que desea dar de baja\n");
    scanf("%d",&aux);
    auxIndice=buscarProducto(lista,tam,aux);
    if(auxIndice == -1)
    {
        printf("el codigo: %d ,no se ha encontrado\n",aux);
    }
    else
    {

        auxProducto=lista[auxIndice];
        mostrarProducto(auxProducto);

        printf("�es el producto q desea borrar? [s|n]");
        setbuf(stdin,NULL);
        scanf("%c",&seguir);
        seguir=tolower(seguir);
        if(seguir=='s')
        {
            lista[auxIndice].estado=0;
            printf("el producto ha sido dado de baja correctamente\n");
        }
        else
        {
            printf("el producto NO se borrara\n");
        }
    }
    return 0;
}


int modificar(eProducto lista[],int tam)
{
    eProducto auxProducto;
    int aux,auxIndice;
    int flag=0;
    char seguir='s';
    int opcion=0;

    printf("escriba el codigo del producto que desea modificar\n");
    scanf("%d",&aux);
    auxIndice=buscarProducto(lista,tam,aux);
    if(auxIndice == -1)
    {
        printf("el codigo: %d ,no se ha encontrado\n",aux);
    }
    else
    {
        flag=1;
        auxProducto=lista[auxIndice];
        mostrarProducto(auxProducto);
        printf("�es el producto q desea modificar? [s|n]");
        setbuf(stdin,NULL);
        scanf("%c",&seguir);
        seguir=tolower(seguir);
        while(seguir=='s')
        {
            printf("1- modificar descripcion\n");
            printf("2- Modificar importe\n");
            printf("3- modificar stock\n\n");
            printf("4- Salir\n");
            setbuf(stdin,NULL);
            scanf("%d",&opcion);


            switch(opcion)
            {
            case 1:
                printf("ingrese la descripcion: \n");
                setbuf(stdin,NULL);
                scanf("%[^\n]",lista[auxIndice].descrip);
                break;
            case 2:
                printf("ingrese el importe: \n");
                setbuf(stdin,NULL);
                scanf("%f",&lista[auxIndice].importe);
                break;
            case 3:
                printf("ingrese el stock: \n");
                setbuf(stdin,NULL);
                scanf("%d",&lista[auxIndice].cantidad);
                break;
            case 4:
                seguir = 'n';
                break;

            default:
                system("cls");
                printf("\n\tOpcion invalida\n\n");
                break;
            }
            system("pause");
            system("cls");
        }
    }

    if(flag!=0)
    {
        printf("el producto ha sido modificado correctamente\n");
    }

    return 0;
}

void mostrarProducto(eProducto producto)
{
    printf("codigo: %d\tprecio: %.2f\tstock: %d\ndescripcion: %s\n\n",producto.codigo,producto.importe,producto.cantidad,producto.descrip);
    return;
}

int buscarProducto(eProducto lista[],int tam,int codigo)
{
    int i;
    int indice= -1;
    for(i=0; i<tam; i++)
    {
        if(lista[i].estado==1 && lista[i].codigo==codigo)
        {
            indice=i;
            break;
        }
    }
    return indice;
}


void orden(eProducto lista[],int tam)
{
    eProducto aux;
    int i,j;
    for(i=0; i<tam-1; i++)
    {
        for(j=i+1; j<tam; j++)
        {
            if(lista[i].importe<lista[j].importe)
            {
                aux=lista[i];
                lista[i]=lista[j];
                lista[j]=aux;
            }
            else if(lista[i].importe==lista[j].importe)
            {

                if(strcmp(lista[i].descrip,lista[j].descrip)<0)
                {
                    aux=lista[i];
                    lista[i]=lista[j];
                    lista[j]=aux;
                }
            }
        }
    }

    mostrar(lista,tam);
    return;
}

void informar(eProducto lista[],int tam,eProveedor prov[],int cant)
{
    int i;
    float promedio=0;
    float total=0;
    float acumulador=0;
    int acumuladorMayor=0;
    int acumuladorMenor=0;
    int acuMenos10=0;
    int acuMas10=0;
    for(i=0;i<tam;i++)
    {
       total=total+lista[i].importe;
        acumulador++;

    }
    promedio=total/(acumulador-1);
    for(i=0;i<tam;i++)
    {
      if(lista[i].importe>=promedio)
      {
          acumuladorMayor++;

      }
      else
      {
          acumuladorMenor++;
      }
    }

    for(i=0;i<tam;i++)
    {
        if(lista[i].cantidad<=10)
        {
            acuMenos10++;

        }
        else
        {
            acuMas10++;
        }
    }

    for(i=0;i<tam;i++)
    {
      if(lista[i].importe>=promedio)
      {
          printf("producto q supera el promedio(%.2f)de precio: %s\n",promedio,lista[i].descrip);

      }
    }
    system("pause");
     for(i=0;i<tam;i++)
    {
      if(lista[i].importe<promedio)
      {
          printf("producto q no supera el promedio(%.2f) de precio: %s\n",promedio,lista[i].descrip);

      }
    }
    system("pause");

    for(i=0;i<tam;i++)
    {
        if(lista[i].cantidad<=10)
        {
            printf("\nproducto con stock menor o igual a 10: %s\t:%d\n",lista[i].descrip,lista[i].cantidad);

        }
    }
    system("pause");

    for(i=0;i<tam;i++)
    {
        if(lista[i].cantidad>10)
        {
            printf("\nproducto con stock mayor a 10: %s\t:%d\n",lista[i].descrip,lista[i].cantidad);

        }
    }
    system("pause");

    printf("total: %.2f\tpromedio: %.2f\tcantidad de productos: %.2f\n\n",total,promedio,acumulador);
    printf("productos q superan el promedio: %d\tProductos q no superan el promedio: %d\n\n",acumuladorMayor,acumuladorMenor);
    printf("productos con mas de 10: %d\n\n",acuMas10);
    printf("productos con stock menor a 10: %d\n",acuMenos10);

}
